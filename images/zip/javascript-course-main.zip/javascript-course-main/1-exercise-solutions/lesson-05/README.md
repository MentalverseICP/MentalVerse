# Exercises
![Exercises 5](https://user-images.githubusercontent.com/70604577/229873760-6bb51ed0-323a-47a7-843a-7f5b1715b684.png)
![Exercises 5 2](https://user-images.githubusercontent.com/70604577/229873752-3f573397-17e0-4489-b454-1ea281487b27.png)
![Exercises 5 3](https://user-images.githubusercontent.com/70604577/229873755-69fa9ce7-4908-49a8-8268-68018c54514f.png)
![Exercises 5 4](https://user-images.githubusercontent.com/70604577/229873756-8fe4eade-bb0e-4a98-982d-54fee73c3eb5.png)
