![Exercises 18 1](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/1b0dbd5e-5ccd-4950-bc1e-3128a075ed18)

![Exercises 18 2](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/7bf8994f-aab7-45e7-ab1d-5b916e139c96)

![Exercises 18 3](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/baf9c11a-1755-4e58-9362-287bf4bcdccf)

![Exercises 18 4](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/32a3437f-7426-4906-aa71-0a381912d509)

![Exercises 18 5](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/6c7555a9-0148-4243-a41e-d66d33aae436)

![Exercises 18 6](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/9503fca7-afd0-4393-9ad8-cf027c4c6c46)

![Exercises 18 7](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/9b151a11-3300-4d4d-b844-545365d30bc9)




