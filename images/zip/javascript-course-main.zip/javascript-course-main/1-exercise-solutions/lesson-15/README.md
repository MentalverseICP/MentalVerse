# Exercises
![Exercises 15 1](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/53a9b4f3-4b02-49ff-a403-62783a86d7e6)
![Exercises 15 2](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/38fc3311-a1e5-409f-801d-ea888ed76863)
![Exercises 15 3](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/3f210952-ff98-4ec5-b23f-a129887107f4)
![Exercises 15 4](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/cfcadebb-3bbd-414e-8209-53e82f477a5c)
![Exercises 15 5](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/d86cf7bc-6636-4034-b516-8a563eff6ac4)
![Exercises 15 6](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/bdd6fd0b-60bf-45f6-af50-77e42a0d45f7)
