# Exercises
![Exercises 2](https://user-images.githubusercontent.com/70604577/229873224-6788a1dd-eb4c-4d71-8dbc-e5e942256cd1.png)
![Exercises 2 2](https://user-images.githubusercontent.com/70604577/229873221-ff160432-acf5-419d-82a5-01eccab072ff.png)
![Exercises 2 3](https://user-images.githubusercontent.com/70604577/229873223-964a1973-a312-4c43-b5e3-c51ada40deac.png)
