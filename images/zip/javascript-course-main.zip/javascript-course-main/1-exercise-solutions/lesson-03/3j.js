alert(`Total cost: $${(599 + 295) / 100}
Thank you, come again!`);